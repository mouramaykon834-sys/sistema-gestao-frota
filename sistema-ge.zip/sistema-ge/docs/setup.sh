#!/bin/bash
# ══════════════════════════════════════════════
# TMS Operacional — Script de Setup Inicial
# Execute: bash docs/setup.sh
# ══════════════════════════════════════════════

echo "🚛 TMS Operacional v4.0 — Setup Inicial"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# Verificar Node.js
if ! command -v node &>/dev/null; then
  echo "❌ Node.js não encontrado. Instale em nodejs.org"
  exit 1
fi
echo "✅ Node.js $(node -v) detectado"

# Instalar dependências
echo ""
echo "📦 Instalando firebase-tools..."
npm install

# Login Firebase
echo ""
echo "🔐 Fazendo login no Firebase..."
echo "   (Será aberta uma janela no navegador)"
npx firebase-tools login

# Listar projetos
echo ""
echo "📋 Seus projetos Firebase:"
npx firebase-tools projects:list

# Associar projeto
echo ""
read -p "Digite o ID do seu projeto Firebase: " PROJECT_ID
npx firebase-tools use "$PROJECT_ID"
sed -i "s/SEU-PROJETO-ID-AQUI/$PROJECT_ID/g" .firebaserc
echo "✅ Projeto configurado: $PROJECT_ID"

# Deploy das regras
echo ""
echo "🔒 Fazendo deploy das regras e índices do Firestore..."
npx firebase-tools deploy --only firestore

# Deploy do hosting
echo ""
echo "🚀 Fazendo deploy do sistema..."
npx firebase-tools deploy --only hosting

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "✅ DEPLOY CONCLUÍDO!"
echo ""
echo "🌐 Acesse: https://$PROJECT_ID.web.app"
echo ""
echo "⚠  Não se esqueça de:"
echo "   1. Colar o firebaseConfig no public/index.html"
echo "   2. Ver docs/CONFIGURACAO.md para detalhes"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
