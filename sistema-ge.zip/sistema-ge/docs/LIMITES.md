# 📊 Limites do Firebase Gratuito (Spark Plan)

## Firestore Database

| Operação   | Limite/dia | Uso estimado (400 caminhões) | Status |
|------------|------------|------------------------------|--------|
| Leituras   | 50.000     | ~8.000 (listeners × docs)    | ✅ OK  |
| Escritas   | 20.000     | ~2.000 (registros do dia)    | ✅ OK  |
| Exclusões  | 20.000     | ~200                          | ✅ OK  |
| Armazen.   | 1 GB       | ~50 MB estimado               | ✅ OK  |

## Firebase Hosting

| Recurso     | Limite       | Uso estimado      | Status |
|-------------|--------------|-------------------|--------|
| Storage     | 10 GB        | ~5 MB (1 HTML)    | ✅ OK  |
| Transferência | 360 MB/dia | ~50 MB/dia        | ✅ OK  |
| Domínio     | .web.app     | Incluído          | ✅ OK  |

## Firebase Authentication

| Recurso     | Limite     | Uso      | Status |
|-------------|------------|----------|--------|
| Usuários    | Ilimitado  | 7 ops.   | ✅ OK  |
| Logins/dia  | Ilimitado  | ~50/dia  | ✅ OK  |

## Dicas para economizar leituras

- O sistema usa `onSnapshot` (listener) que conta
  como 1 leitura por documento na conexão inicial
  e 1 leitura por documento alterado (não relê tudo)
- Com 400 motoristas: ~400 leituras iniciais por sessão
- 7 operadores × 400 = 2.800 leituras ao abrir o dia
- Sobram ~47.200 leituras para atualizações em tempo real
- Limite diário não será atingido normalmente
