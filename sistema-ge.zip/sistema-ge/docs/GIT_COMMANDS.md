# 🐙 Comandos Git — Subir para o GitHub

## Primeira vez (configurar o repositório)

```bash
# 1. Entrar na pasta do projeto
cd sistema-ge

# 2. Inicializar o Git (se ainda não foi feito)
git init

# 3. Adicionar o repositório remoto (seu repo no GitHub)
git remote add origin https://github.com/mouramaykon834/sistema-ge.git

# 4. Adicionar todos os arquivos
git add .

# 5. Criar o primeiro commit
git commit -m "feat: estrutura inicial do TMS Operacional v4.0"

# 6. Renomear branch para main (padrão atual)
git branch -M main

# 7. Subir para o GitHub
git push -u origin main
```

---

## Deploy via commit (dia a dia)

```bash
# Quando atualizar o sistema:
git add .
git commit -m "feat: descrição do que foi alterado"
git push

# O GitHub Actions fará o deploy automático no Firebase!
```

---

## Comandos úteis

```bash
# Ver status dos arquivos
git status

# Ver histórico de commits
git log --oneline

# Ver qual remote está configurado
git remote -v

# Puxar atualizações (se mais de uma pessoa trabalha)
git pull origin main
```

---

## Segredos necessários no GitHub

Para o deploy automático funcionar, adicione em:
**Repositório → Settings → Secrets and variables → Actions → New repository secret**

| Secret Name               | Como Obter                                          |
|---------------------------|-----------------------------------------------------|
| `FIREBASE_TOKEN`          | Execute: `bash docs/get-firebase-token.sh`          |
| `FIREBASE_PROJECT_ID`     | ID do projeto no console.firebase.google.com        |
| `FIREBASE_SERVICE_ACCOUNT`| Firebase → Configurações → Contas de serviço → JSON |

