#!/bin/bash
# Gera o token para usar no GitHub Actions Secret FIREBASE_TOKEN
echo "🔑 Gerando Firebase CI Token..."
echo "   (Abrirá o navegador para autenticação)"
echo ""
npx firebase-tools login:ci
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "Copie o token acima e adicione no GitHub:"
echo "  Repo → Settings → Secrets → FIREBASE_TOKEN"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
