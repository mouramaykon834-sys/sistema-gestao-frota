# 🔧 Guia de Configuração Detalhado

## Passo 1 — Clonar o repositório

```bash
git clone https://github.com/mouramaykon834/sistema-ge.git
cd sistema-ge
npm install
```

## Passo 2 — Configurar o firebaseConfig

Abra `public/index.html` e localize:

```javascript
const FIREBASE_CONFIG = {
  apiKey:            "COLE_SUA_API_KEY",
  authDomain:        "COLE_SEU_PROJETO.firebaseapp.com",
  projectId:         "COLE_SEU_PROJETO_ID",
  storageBucket:     "COLE_SEU_PROJETO.appspot.com",
  messagingSenderId: "COLE_SEU_SENDER_ID",
  appId:             "COLE_SEU_APP_ID"
};
```

Substitua pelos valores do seu projeto Firebase
(Console → Configurações → Seus apps → Config do SDK).

## Passo 3 — Configurar .firebaserc

Edite o arquivo `.firebaserc`:
```json
{
  "projects": {
    "default": "SEU-PROJETO-ID-REAL"
  }
}
```

## Passo 4 — Deploy das regras do Firestore

```bash
npx firebase-tools login
npx firebase-tools deploy --only firestore
```

## Passo 5 — Deploy do sistema

```bash
npm run deploy
```

## Passo 6 — Primeiro acesso

1. Acesse `https://SEU-PROJETO.web.app`
2. O sistema detectará que não há usuários
3. Preencha: nome, e-mail e senha do administrador
4. Clique em **Criar Administrador**
5. Pronto! O sistema está configurado.
