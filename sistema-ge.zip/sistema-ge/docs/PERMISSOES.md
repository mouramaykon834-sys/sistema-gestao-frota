# 👥 Guia de Perfis e Permissões

## Perfis Disponíveis

### 🔴 Administrador (admin)
- Acesso total ao sistema
- Cria, edita e exclui qualquer dado
- Gerencia usuários e perfis
- Acessa log de auditoria completo
- Vê todos os grupos e motoristas
- Pode fazer deploy e alterar configurações

### 🟡 Supervisor (supervisor)
- Vê motoristas dos grupos vinculados ao seu perfil
- Cria e edita motoristas, registros e folgas
- Não acessa gerenciamento de usuários
- Não acessa auditoria
- Não exclui motoristas (apenas admin)

### 🟢 Operador (operador)
- Vê apenas motoristas dos grupos vinculados
- Cria registros operacionais e folgas
- Não edita nem exclui dados existentes
- Acesso somente leitura nos demais módulos

## Como Configurar Grupos

1. Admin cria os grupos em **Gestão de Grupos**
2. Admin cadastra os motoristas vinculando ao grupo
3. Admin cria o usuário operador/supervisor
4. Na criação do usuário, marca os grupos que ele acessa
5. Ao logar, operador vê automaticamente apenas seu grupo

## Exemplo de Configuração para 7 Operadores

```
Grupo 1: Frota Norte     → Operador: João
Grupo 2: Frota Sul       → Operador: Maria
Grupo 3: Frota Leste     → Operador: Carlos
Grupo 4: Frota Oeste     → Operador: Ana
Supervisor Geral         → Grupos: 1, 2, 3, 4
Administrador            → Todos os grupos
```
