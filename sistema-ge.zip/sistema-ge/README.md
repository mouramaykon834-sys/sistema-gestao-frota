# 🚛 TMS Operacional v4.0 — Sistema de Controle de Jornada

Sistema web de controle de jornada de motoristas com sincronização
em tempo real, multiusuário, usando Firebase como backend gratuito.

---

## ⚡ Stack

| Serviço        | Uso                          | Plano   |
|----------------|------------------------------|---------|
| Firebase Auth  | Login de usuários            | Gratuito |
| Firestore      | Banco de dados em tempo real | Gratuito |
| Firebase Hosting | Hospedagem do sistema      | Gratuito |
| GitHub         | Repositório + CI/CD          | Gratuito |

---

## 📁 Estrutura do Projeto

```
sistema-ge/
├── public/
│   └── index.html          ← Sistema TMS completo (único arquivo)
├── .github/
│   └── workflows/
│       └── deploy.yml      ← Deploy automático ao fazer push
├── docs/
│   ├── CONFIGURACAO.md     ← Guia de configuração do Firebase
│   ├── LIMITES.md          ← Limites do plano gratuito
│   └── PERMISSOES.md       ← Guia de perfis e permissões
├── firebase.json           ← Config do Firebase Hosting
├── firestore.rules         ← Regras de segurança do Firestore
├── firestore.indexes.json  ← Índices para performance
├── .firebaserc             ← ID do projeto Firebase
├── .gitignore
├── package.json
└── README.md
```

---

## 🚀 Como Configurar (5 passos)

### 1. Firebase — Criar Projeto
1. Acesse [console.firebase.google.com](https://console.firebase.google.com)
2. Clique em **Adicionar projeto**
3. Dê um nome (ex: `sistema-ge`)
4. Desative Google Analytics (opcional)
5. Clique em **Criar projeto**

### 2. Firebase — Ativar Firestore
1. No menu esquerdo: **Criação → Banco de dados Firestore**
2. Clique em **Criar banco de dados**
3. Escolha **Modo de produção**
4. Selecione região mais próxima (`southamerica-east1` = São Paulo)

### 3. Firebase — Ativar Authentication
1. No menu: **Criação → Authentication**
2. Clique em **Começar**
3. Em **Provedores de login** → ative **E-mail/Senha**

### 4. Firebase — Obter Credenciais
1. No menu: **Configurações do projeto** (ícone ⚙️)
2. Role até **Seus aplicativos** → clique em **</>** (Web)
3. Registre o app com um nome
4. Copie o objeto `firebaseConfig`
5. Cole no arquivo `public/index.html` substituindo os placeholders

### 5. Primeiro Deploy
```bash
# Instalar Firebase CLI
npm install

# Login no Firebase
npx firebase-tools login

# Associar ao seu projeto
npx firebase-tools use SEU-PROJETO-ID

# Deploy completo
npm run deploy
```

---

## 🔐 Configurar GitHub Actions (deploy automático)

Ao fazer `git push main`, o sistema faz deploy automático.

**Adicionar Secrets no GitHub:**
1. Repositório → Settings → Secrets and variables → Actions
2. Adicionar:
   - `FIREBASE_TOKEN` → obter com `npx firebase-tools login:ci`
   - `FIREBASE_PROJECT_ID` → ID do seu projeto Firebase
   - `FIREBASE_SERVICE_ACCOUNT` → chave de serviço (JSON do Firebase)

---

## 📊 Limites do Plano Gratuito (Spark)

| Recurso            | Limite Gratuito  | Estimativa para 400 caminhões |
|--------------------|------------------|-------------------------------|
| Leituras Firestore | 50.000/dia       | ~8.000/dia (OK ✅)             |
| Escritas Firestore | 20.000/dia       | ~2.000/dia (OK ✅)             |
| Exclusões          | 20.000/dia       | ~200/dia (OK ✅)               |
| Armazenamento      | 1 GB             | ~50 MB (OK ✅)                 |
| Hosting (storage)  | 10 GB            | ~5 MB (OK ✅)                  |
| Hosting (transfer) | 360 MB/dia       | ~50 MB/dia (OK ✅)             |
| Auth usuários      | Ilimitado        | 7 usuários (OK ✅)             |

---

## 👥 Perfis de Usuário

| Perfil       | Dashboard | Motoristas | Registros | Usuários | Auditoria |
|--------------|-----------|------------|-----------|----------|-----------|
| Admin        | Tudo      | CRUD       | CRUD      | ✅        | ✅         |
| Supervisor   | Grupos    | Editar     | CRUD      | ❌        | ❌         |
| Operador     | Grupos    | Ver        | Criar     | ❌        | ❌         |

---

## 🛠️ Comandos Úteis

```bash
# Servir localmente (sem deploy)
npm run serve

# Deploy apenas do sistema (HTML)
npm run deploy:hosting

# Deploy apenas das regras de segurança
npm run deploy:rules

# Deploy apenas dos índices
npm run deploy:indexes

# Deploy completo
npm run deploy
```

---

## 📱 Acesso

Após o deploy, o sistema estará disponível em:
```
https://SEU-PROJETO-ID.web.app
```

---

*TMS Operacional v4.0 · Firebase + GitHub · 100% Gratuito*
